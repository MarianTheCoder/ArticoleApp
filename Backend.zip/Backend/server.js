const express = require("express");
const mysql = require("mysql2/promise");
const bodyParser = require("body-parser");
const articlesRoutes = require("./Routes/ArticlesRoutes");
const cors = require("cors");
const bcrypt = require('bcrypt');

const loginRoute = require('./Routes/LoginRoutes');

const app = express();
const port = 443;

// Middleware
app.use(bodyParser.json());
app.use(cors({ origin: 'https://balyenergies.fr' }));

// MySQL Connection Configuration
const dbConfig = {
  host: "localhost",
  user: "iasirecr_baly_energies",
  password: "saps2002c",
  database: "iasirecr_baza_de_date",
};

const pool = mysql.createPool(dbConfig);

// Function to initialize the database
async function initializeDatabase() {
  try {
    console.log("Connected to MySQL database.");

    // Create `users` table
    const createPasswordTableQuery = `
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('ofertant', 'angajat', 'beneficiar') NOT NULL DEFAULT 'ofertant'
      );
    `;

    await pool.execute(createPasswordTableQuery);
    console.log("Users table created or already exists.");

    // Create `articole` table
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS articole (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type ENUM('Category 1', 'Category 2', 'Category 3', 'Category 4') NOT NULL DEFAULT 'Category 1',
        description TEXT NOT NULL,
        code VARCHAR(50) NOT NULL,
        unit VARCHAR(10) NOT NULL,
        norma DECIMAL(10, 2) NOT NULL,
        data DATE NOT NULL
      );
    `;
    await pool.execute(createTableQuery);
    console.log("Table created or already exists.");

    // Insert initial admin user
    await insertInitialAdminUser();
    global.db = pool;
  } catch (err) {
    console.error("Error initializing database:", err);
    process.exit(1);
  }
}

async function insertInitialAdminUser() {
  try {
    const username = 'AdminBoss22';
    const plainPassword = 'admin22!!';
    const role = 'ofertant';

    const [existingUser] = await pool.execute(
      'SELECT * FROM users WHERE username = ?',
      [username]
    );

    if (existingUser.length > 0) {
      console.log('Admin user already exists. Skipping insertion.');
      return;
    }

    const hashedPassword = await bcrypt.hash(plainPassword, 10);
    const insertQuery = `
      INSERT INTO users (username, password, role) 
      VALUES (?, ?, ?)
    `;

    await pool.execute(insertQuery, [username, hashedPassword, role]);
    console.log('Admin user inserted successfully.');
  } catch (err) {
    console.error('Error inserting admin user:', err);
  }
}

app.use('/articles', articlesRoutes);
app.use('/auth', loginRoute);

app.listen(port, async () => {
  console.log(`Server is running on https://localhost:${port}`);
  await initializeDatabase();
});
