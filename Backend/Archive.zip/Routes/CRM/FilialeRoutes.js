const express = require('express');
const { } = require("../../Controllers/CRM/SantiereController")
const { authenticateToken } = require('../../Middleware/authMiddleware');
const { postFiliala, editFiliala, deleteFiliala, getFilialeByCompany, getFilialeForSantiere } = require('../../Controllers/CRM/FilialeController');

const router = express.Router();

router.post('/postFiliala', postFiliala);
router.post('/editFiliala/:id', editFiliala);
router.delete('/deleteFiliala/:id', authenticateToken, deleteFiliala); // Placeholder for delete route

router.get('/getFilialeForCompanies/:id', getFilialeByCompany);
router.get('/getFilialeForSantiere/:id', getFilialeForSantiere);


module.exports = router;