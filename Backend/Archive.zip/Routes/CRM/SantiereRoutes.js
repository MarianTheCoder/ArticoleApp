const express = require('express');
const { } = require("../../Controllers/CRM/SantiereController")
const { authenticateToken } = require('../../Middleware/authMiddleware');
const { getSantiereByCompany, deleteSantier, getSantiereForContacte, editSantier, postSantier } = require('../../Controllers/CRM/SantiereController');

const router = express.Router();

router.post('/postSantier', postSantier);
router.post('/editSantier/:id', editSantier);
router.delete('/deleteSantier/:id', authenticateToken, deleteSantier); // Placeholder for delete route

router.get('/getSantiereForCompanies/:id', getSantiereByCompany);
router.get('/getSantiereForContacte/:id', getSantiereForContacte);


module.exports = router;